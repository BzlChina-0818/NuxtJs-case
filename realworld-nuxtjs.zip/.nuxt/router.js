import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _9a1a149c = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _0ad41d32 = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _586083e1 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _c9143fbe = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _648634ab = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _b1b7c816 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _fb7fb924 = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _9a1a149c,
    children: [{
      path: "",
      component: _0ad41d32,
      name: "home"
    }, {
      path: "/login",
      component: _586083e1,
      name: "login"
    }, {
      path: "/register",
      component: _586083e1,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _c9143fbe,
      name: "profile"
    }, {
      path: "/settings",
      component: _648634ab,
      name: "settings"
    }, {
      path: "/editor",
      component: _b1b7c816,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _fb7fb924,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
